package com.epam.university.java.core.task015;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

/**
 * Author Dmitry Novikov 27-Sep-20.
 */
public class Task015Impl implements Task015 {
    SquareFactory squareFactory = new SquareFactoryImpl();
    PointFactory pointFactory = new PointFactoryImpl();



    @Override
    public double getArea(Square first, Square second) {

        if (first.getFirst().getX() == first.getSecond().getX() ||
                first.getFirst().getY() == first.getSecond().getY() ||
              second.getFirst().getX() == second.getSecond().getX() ||
              second.getFirst().getY() == second.getSecond().getY()
        ) {
            return getAreaNew(first,second);
        }

        first = normalize(first);
        second = normalize(second);



        double left = Math.max(first.getFirst().getX(), second.getFirst().getX());
        double top = Math.min(first.getSecond().getY(), second.getSecond().getY());
        double right = Math.min(first.getSecond().getX(), second.getSecond().getX());
        double bottom = Math.max(first.getFirst().getY(), second.getFirst().getY());

        double width = right - left;
        double height = top - bottom;

        if (width < 0 || height < 0) {
            return 0;
        }

        return width * height;
    }

    private Square normalize(Square input) {
        double minX = Math.min(input.getFirst().getX(), input.getSecond().getX());
        double maxX = Math.max(input.getFirst().getX(), input.getSecond().getX());
        double minY = Math.min(input.getFirst().getY(), input.getSecond().getY());
        double maxY = Math.max(input.getFirst().getY(), input.getSecond().getY());

        return squareFactory.newInstance(pointFactory.newInstance(minX,minY),
                pointFactory.newInstance(maxX,maxY));
    }

    //----------------------------------
    private double getAreaNew(Square first, Square second){

        List<Point> firstSquare = fillSquareWithPoints(first.getFirst(), first.getSecond());
        List<Point> secondSquare = fillSquareWithPoints(second.getFirst(), second.getSecond());
        List<Point> intersection = findIntersectedPoints(firstSquare, secondSquare);
        List<Point> pointsToCalcArea = find3Points(intersection);
        double areaCalculated = -1;
        if (intersection.size() == 5) {
            areaCalculated = calcResult(pointsToCalcArea) * 2;
        }

        if (intersection.size() == 4) {
            areaCalculated = calcResult(pointsToCalcArea);
        }

        if (intersection.size() == 1) {
            return 0.5;
        }

        return areaCalculated;
    }

    private double calcResult(List<Point> pointsToCalcArea){
        double area =
                (pointsToCalcArea.get(0).getX() * (pointsToCalcArea.get(1).getY() - pointsToCalcArea.get(2).getY())
                        + pointsToCalcArea.get(1).getX() * (pointsToCalcArea.get(2).getY() - pointsToCalcArea.get(0).getY())
                        + pointsToCalcArea.get(2).getX()* (pointsToCalcArea.get(0).getY() - pointsToCalcArea.get(1).getY()))
                        / 2.0;
        return Math.abs(area);
    }


    private List<Point> fillSquareWithPoints(Point p1, Point p2) {
        List<Point> result = new ArrayList<>();
        result.add(p1);
        result.add(p2);
        int lenght;
        int halfLenght;
        if (p1.getY() == p2.getY()) {
            lenght = (int) Math.abs(p2.getX() - p1.getX());
            halfLenght = lenght / 2;
            if (halfLenght == 2) {

                result.add(new PointImpl(p1.getX() + (halfLenght - 1), p1.getY() + (halfLenght - 1)));
                result.add(new PointImpl(p1.getX() + (halfLenght - 1), p1.getY() - (halfLenght - 1)));
                result.add(new PointImpl(p1.getX() + (halfLenght - 1), p1.getY()));

                result.add(new PointImpl(p1.getX() + halfLenght, p1.getY() + halfLenght));
                result.add(new PointImpl(p1.getX() + halfLenght, p1.getY() + (halfLenght - 1)));
                result.add(new PointImpl(p1.getX() + halfLenght, p1.getY() - halfLenght));
                result.add(new PointImpl(p1.getX() + halfLenght, p1.getY() + (halfLenght - 3)));
                result.add(new PointImpl(p1.getX() + halfLenght, p1.getY()));

                result.add(new PointImpl(p1.getX() + (halfLenght + 1), p1.getY() + (halfLenght - 3)));
                result.add(new PointImpl(p1.getX() + (halfLenght + 1), p1.getY() - (halfLenght - 3)));
                result.add(new PointImpl(p1.getX() + (halfLenght + 1), p1.getY()));
            }

        } else if (p1.getX() == p2.getX()) {
            lenght = (int) Math.abs(p2.getY() - p1.getY());
            halfLenght = lenght / 2;
            if (halfLenght == 2) {

                result.add(new PointImpl(p1.getX() - 1, p1.getY() + 1));
                result.add(new PointImpl(p1.getX() + 1, p1.getY() + 1));
                result.add(new PointImpl(p1.getX(), p1.getY() + 1));


                result.add(new PointImpl(p1.getX() - 2, p1.getY() + 2));
                result.add(new PointImpl(p1.getX() + 2, p1.getY() + 2));
                result.add(new PointImpl(p1.getX() - 1, p1.getY() + 2));
                result.add(new PointImpl(p1.getX() + 1, p1.getY() + 2));
                result.add(new PointImpl(p1.getX(), p1.getY() + 2));

                result.add(new PointImpl(p1.getX() - 1, p1.getY() + 3));
                result.add(new PointImpl(p1.getX() + 1, p1.getY() + 3));
                result.add(new PointImpl(p1.getX(), p1.getY() + 3));
            }
                 }
        else {
                    // написать код для нормального квадрата когда параллельно оси х
                    Point startPoint;
                    lenght = (int) Math.abs(p2.getX() - p1.getX());
                    if (p1.getX() < p2.getX() && p1.getY() < p2.getY()) {
                        startPoint = p1;
                    } else {
                        startPoint = p2;
                    }
                    result.clear();
                    if (startPoint.getY() < p1.getY()) {
                        startPoint = p1;

                        int startX = (int) startPoint.getX();
                        int startY = (int) startPoint.getY();
                        for (int i = startY; i >= (startY - lenght); i--) {
                            for (int j = startX; j <= (startX + lenght) ; j++) {
                                result.add(new PointImpl(j, i));
                            }
                        }

                    } else {
                        startPoint = p2;
                        int startX = (int) startPoint.getX();
                        int startY = (int) startPoint.getY();
                        for (int i = startX; i <= (startX + lenght); i++) {
                            for (int j = startY; j <= (startY + lenght); j++) {
                                result.add(new PointImpl(startX, startY));
                            }
                        }
                    }
                }
        return result;
    }

    private List<Point> findIntersectedPoints(List<Point> firstSquare, List<Point> secondSquare) {
        List<Point> intersection = new ArrayList<>();
        for (int i = 0; i < firstSquare.size(); i++) {
            for (int j = 0; j < secondSquare.size(); j++) {
                if (firstSquare.get(i).equals(secondSquare.get(j))) {
                    intersection.add(firstSquare.get(i));
                }
            }
        }
        return intersection;
    }

    private List<Point> find3Points(List<Point> intersection){
        List<Point> result = new ArrayList<>();
        Point a = null;
        Point b = null;
        Point c = null;

        if (intersection.size() == 5 || intersection.size() ==4) {
//            Comparator<Point> minX = Comparator.comparing(PointImpl::getX, Double::compareTo);
            Comparator<Point> minX = Comparator.comparing(x -> x.getX(), Double::compareTo);
            Comparator<Point> minY = Comparator.comparing(y -> y.getY(), Double::compareTo);
            Comparator<Point> maxY = minY.reversed();

            Collections.sort(intersection, minX);
            a = intersection.get(0);
            Collections.sort(intersection, minY);
            b = intersection.get(0);
            Collections.sort(intersection, maxY);
            c= intersection.get(0);
        }

        result.add(a);
        result.add(b);
        result.add(c);

        return result;
    }

}
